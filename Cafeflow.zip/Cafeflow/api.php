<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

// Database connection
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "cafeflow_db";
$port = "3307";

$conn = mysqli_connect($host, $user, $pass, $dbname, $port);

if (!$conn) {
    echo json_encode(["success" => false, "message" => "Database connection failed: " . mysqli_connect_error()]);
    exit;
}

mysqli_set_charset($conn, "utf8");

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Get the action from query string
$action = $_GET['action'] ?? '';

// Helper function to send JSON response
function sendResponse($success, $data = null, $message = "") {
    echo json_encode([
        "success" => $success,
        "data" => $data,
        "message" => $message
    ]);
    exit;
}

// Handle different actions
switch ($action) {
    case 'get_items':
        getItems($conn);
        break;
    
    case 'get_item':
        getItem($conn);
        break;
    
    case 'add_item':
        addItem($conn);
        break;
    
    case 'update_item':
        updateItem($conn);
        break;
    
    case 'delete_item':
        deleteItem($conn);
        break;
    
    case 'get_categories':
        getCategories($conn);
        break;
    
    default:
        sendResponse(false, null, "Invalid action");
}

// ====== FUNCTIONS ======

function getItems($conn) {
    $sql = "SELECT * FROM items ORDER BY name ASC";
    $result = mysqli_query($conn, $sql);
    
    if (!$result) {
        sendResponse(false, null, "Error fetching items: " . mysqli_error($conn));
    }
    
    $items = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $items[] = $row;
    }
    
    sendResponse(true, $items, "Items fetched successfully");
}

function getItem($conn) {
    if (!isset($_GET['id'])) {
        sendResponse(false, null, "Item ID is required");
    }
    
    $id = intval($_GET['id']);
    $sql = "SELECT * FROM items WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    if ($row = mysqli_fetch_assoc($result)) {
        sendResponse(true, $row, "Item fetched successfully");
    } else {
        sendResponse(false, null, "Item not found");
    }
}

function addItem($conn) {
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($data['name']) || !isset($data['category']) || 
        !isset($data['price']) || !isset($data['stock'])) {
        sendResponse(false, null, "All fields are required");
    }
    
    $name = mysqli_real_escape_string($conn, trim($data['name']));
    $category = mysqli_real_escape_string($conn, trim($data['category']));
    $price = floatval($data['price']);
    $stock = intval($data['stock']);
    
    $sql = "INSERT INTO items (name, category, price, stock) VALUES (?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ssdi", $name, $category, $price, $stock);
    
    if (mysqli_stmt_execute($stmt)) {
        $newId = mysqli_insert_id($conn);
        sendResponse(true, ["id" => $newId], "Item added successfully");
    } else {
        sendResponse(false, null, "Error adding item: " . mysqli_error($conn));
    }
}

function updateItem($conn) {
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($data['id'])) {
        sendResponse(false, null, "Item ID is required for update");
    }
    
    $id = intval($data['id']);
    $name = mysqli_real_escape_string($conn, trim($data['name']));
    $category = mysqli_real_escape_string($conn, trim($data['category']));
    $price = floatval($data['price']);
    $stock = intval($data['stock']);
    
    $sql = "UPDATE items SET name = ?, category = ?, price = ?, stock = ? WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ssdii", $name, $category, $price, $stock, $id);
    
    if (mysqli_stmt_execute($stmt)) {
        sendResponse(true, null, "Item updated successfully");
    } else {
        sendResponse(false, null, "Error updating item: " . mysqli_error($conn));
    }
}

function deleteItem($conn) {
    if (!isset($_GET['id'])) {
        sendResponse(false, null, "Item ID is required");
    }
    
    $id = intval($_GET['id']);
    $sql = "DELETE FROM items WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $id);
    
    if (mysqli_stmt_execute($stmt)) {
        sendResponse(true, null, "Item deleted successfully");
    } else {
        sendResponse(false, null, "Error deleting item: " . mysqli_error($conn));
    }
}

function getCategories($conn) {
    $sql = "SELECT DISTINCT category FROM items ORDER BY category ASC";
    $result = mysqli_query($conn, $sql);
    
    if (!$result) {
        sendResponse(false, null, "Error fetching categories: " . mysqli_error($conn));
    }
    
    $categories = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $categories[] = $row['category'];
    }
    
    sendResponse(true, $categories, "Categories fetched successfully");
}

// Close connection
mysqli_close($conn);
?>