<?php
$host = "localhost";
$user = "root";
$pass = ""; // XAMPP empty password
$dbname = "cafeflow_db";
$port = "3307";

// Connect to MySQL database
$conn = mysqli_connect($host, $user, $pass, $dbname, $port);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Optional: Set charset to UTF-8
mysqli_set_charset($conn, "utf8");

echo "Connected successfully!";
?>