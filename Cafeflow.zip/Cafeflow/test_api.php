<?php
// Test script to verify API endpoints
echo "<h2>Testing CafeFlow API</h2>";

// Test 1: Get all items
echo "<h3>Test 1: Get All Items</h3>";
$url = "http://localhost/cafeflow/api.php?action=get_items";
$response = file_get_contents($url);
echo "<pre>" . htmlspecialchars($response) . "</pre>";

// Test 2: Get categories
echo "<h3>Test 2: Get Categories</h3>";
$url = "http://localhost/cafeflow/api.php?action=get_categories";
$response = file_get_contents($url);
echo "<pre>" . htmlspecialchars($response) . "</pre>";
?>