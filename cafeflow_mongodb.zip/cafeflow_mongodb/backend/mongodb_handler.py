from pymongo import MongoClient
from bson import ObjectId
from datetime import datetime

class MongoDBHandler:
    def __init__(self):
        self.client = MongoClient("mongodb://localhost:27017/")
        self.db = self.client["cafeflow"]
        
        # Collections
        self.categories = self.db["categories"]
        self.products = self.db["products"]
        self.customers = self.db["customers"]
        self.employees = self.db["employees"]
        self.users = self.db["users"]
        self.sales = self.db["sales"]
        
        print("[INFO] Connected to MongoDB")
    
    # ========== CATEGORIES ==========
    def get_all_categories(self):
        return list(self.categories.find())
    
    def add_category(self, category_data):
        return self.categories.insert_one(category_data)
    
    # ========== PRODUCTS ==========
    def get_all_products(self):
        return list(self.products.find())
    
    def get_product_by_id(self, product_id):
        return self.products.find_one({"_id": product_id})
    
    def add_product(self, product_data):
        return self.products.insert_one(product_data)
    
    def update_product(self, product_id, product_data):
        return self.products.update_one({"_id": product_id}, {"$set": product_data})
    
    def delete_product(self, product_id):
        return self.products.delete_one({"_id": product_id})
    
    def update_stock(self, product_id, quantity):
        return self.products.update_one(
            {"_id": product_id},
            {"$inc": {"stock": -quantity}}
        )
    
    # ========== CUSTOMERS ==========
    def get_all_customers(self):
        return list(self.customers.find())
    
    def get_customer_by_id(self, customer_id):
        return self.customers.find_one({"_id": customer_id})
    
    def get_customer_by_email(self, email):
        return self.customers.find_one({"email": email})
    
    def add_customer(self, customer_data):
        return self.customers.insert_one(customer_data)
    
    def add_order_to_customer(self, customer_id, order_data):
        return self.customers.update_one(
            {"_id": customer_id},
            {"$push": {"orders": order_data}}
        )
    
    def update_order_status(self, customer_id, order_id, status):
        return self.customers.update_one(
            {"_id": customer_id, "orders.id": order_id},
            {"$set": {"orders.$.status": status}}
        )
    
    # ========== EMPLOYEES ==========
    def get_all_employees(self):
        return list(self.employees.find())
    
    def get_employee_by_id(self, employee_id):
        return self.employees.find_one({"_id": employee_id})
    
    def add_employee(self, employee_data):
        return self.employees.insert_one(employee_data)
    
    def update_employee(self, employee_id, employee_data):
        return self.employees.update_one({"_id": employee_id}, {"$set": employee_data})
    
    def delete_employee(self, employee_id):
        return self.employees.delete_one({"_id": employee_id})
    
    # ========== USERS (Admin Login) ==========
    def get_user_by_username(self, username):
        return self.users.find_one({"username": username})
    
    def add_user(self, user_data):
        return self.users.insert_one(user_data)
    
    # ========== SALES ==========
    def get_all_sales(self):
        return list(self.sales.find())
    
    def add_sale(self, sale_data):
        return self.sales.insert_one(sale_data)
    
    def get_sales_by_date_range(self, start_date, end_date):
        return list(self.sales.find({
            "sale_date": {"$gte": start_date, "$lte": end_date}
        }))
    
    # ========== UTILITY ==========
    def close(self):
        self.client.close()