from flask import Flask, request, jsonify
from flask_cors import CORS
from datetime import datetime
import sys
import os

sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'database'))
from mongodb_handler import MongoDBHandler

app = Flask(__name__)
CORS(app)
db = MongoDBHandler()

# ========== CATEGORIES API ==========
@app.route('/api/categories', methods=['GET'])
def get_categories():
    categories = db.get_all_categories()
    for c in categories:
        c['_id'] = str(c['_id'])
    return jsonify({"success": True, "data": categories})

@app.route('/api/categories', methods=['POST'])
def add_category():
    data = request.json
    category = {
        "_id": data['id'],
        "name": data['name']
    }
    db.add_category(category)
    return jsonify({"success": True, "message": "Category added"})

# ========== PRODUCTS API ==========
@app.route('/api/products', methods=['GET'])
def get_products():
    products = db.get_all_products()
    for p in products:
        p['_id'] = str(p['_id'])
    return jsonify({"success": True, "data": products})

@app.route('/api/products', methods=['POST'])
def add_product():
    data = request.json
    product = {
        "_id": data['id'],
        "name": data['name'],
        "category_id": data['category_id'],
        "price": data['price'],
        "stock": data['stock']
    }
    db.add_product(product)
    return jsonify({"success": True, "message": "Product added"})

@app.route('/api/products/<int:product_id>', methods=['PUT'])
def update_product(product_id):
    data = request.json
    db.update_product(product_id, data)
    return jsonify({"success": True, "message": "Product updated"})

@app.route('/api/products/<int:product_id>', methods=['DELETE'])
def delete_product(product_id):
    db.delete_product(product_id)
    return jsonify({"success": True, "message": "Product deleted"})

# ========== CUSTOMERS API ==========
@app.route('/api/customers', methods=['GET'])
def get_customers():
    customers = db.get_all_customers()
    for c in customers:
        c['_id'] = str(c['_id'])
    return jsonify({"success": True, "data": customers})

@app.route('/api/customers/<int:customer_id>/orders', methods=['GET'])
def get_customer_orders(customer_id):
    customer = db.get_customer_by_id(customer_id)
    if customer:
        return jsonify({"success": True, "data": customer.get('orders', [])})
    return jsonify({"success": False, "message": "Customer not found"}), 404

@app.route('/api/customers/register', methods=['POST'])
def register_customer():
    data = request.json
    
    existing = db.get_customer_by_email(data['email'])
    if existing:
        return jsonify({"success": False, "message": "Email already registered"}), 400
    
    # Get next ID
    all_customers = db.get_all_customers()
    next_id = max([c['_id'] for c in all_customers]) + 1 if all_customers else 1
    
    customer = {
        "_id": next_id,
        "name": data['name'],
        "email": data['email'],
        "password": data['password'],
        "phone": data.get('phone', ''),
        "orders": []
    }
    db.add_customer(customer)
    return jsonify({"success": True, "message": "Customer registered", "customer_id": next_id})

@app.route('/api/customer/login', methods=['POST'])
def customer_login():
    data = request.json
    customer = db.get_customer_by_email(data['email'])
    if customer and data['password'] == customer.get('password'):
        return jsonify({
            "success": True,
            "customer": {
                "id": customer['_id'],
                "name": customer['name'],
                "email": customer['email']
            }
        })
    return jsonify({"success": False, "message": "Invalid credentials"}), 401

@app.route('/api/customers/place_order', methods=['POST'])
def place_order():
    data = request.json
    
    # Get customer's existing orders to determine next order ID
    customer = db.get_customer_by_id(data['customer_id'])
    existing_orders = customer.get('orders', [])
    next_order_id = max([o['id'] for o in existing_orders]) + 1 if existing_orders else 1
    
    order = {
        "id": next_order_id,
        "item_id": data['item_id'],
        "quantity": data['quantity'],
        "total_price": data['total_price'],
        "status": "pending",
        "created_at": datetime.now()
    }
    
    db.add_order_to_customer(data['customer_id'], order)
    db.update_stock(data['item_id'], data['quantity'])
    
    return jsonify({"success": True, "message": "Order placed", "order_id": next_order_id})

@app.route('/api/customers/update_order_status', methods=['POST'])
def update_order_status():
    data = request.json
    db.update_order_status(data['customer_id'], data['order_id'], data['status'])
    return jsonify({"success": True, "message": "Order status updated"})

# ========== EMPLOYEES API ==========
@app.route('/api/employees', methods=['GET'])
def get_employees():
    employees = db.get_all_employees()
    for e in employees:
        e['_id'] = str(e['_id'])
    return jsonify({"success": True, "data": employees})

@app.route('/api/employees', methods=['POST'])
def add_employee():
    data = request.json
    
    all_employees = db.get_all_employees()
    next_id = max([e['_id'] for e in all_employees]) + 1 if all_employees else 1
    
    employee = {
        "_id": next_id,
        "name": data['name'],
        "email": data['email'],
        "phone": data.get('phone', ''),
        "role": data['role'],
        "hourly_rate": data['hourly_rate'],
        "hire_date": datetime.strptime(data['hire_date'], '%Y-%m-%d')
    }
    db.add_employee(employee)
    return jsonify({"success": True, "message": "Employee added", "employee_id": next_id})

@app.route('/api/employees/<int:employee_id>', methods=['PUT'])
def update_employee(employee_id):
    data = request.json
    db.update_employee(employee_id, data)
    return jsonify({"success": True, "message": "Employee updated"})

@app.route('/api/employees/<int:employee_id>', methods=['DELETE'])
def delete_employee(employee_id):
    db.delete_employee(employee_id)
    return jsonify({"success": True, "message": "Employee deleted"})

# ========== SALES API ==========
@app.route('/api/sales', methods=['GET'])
def get_sales():
    sales = db.get_all_sales()
    for s in sales:
        s['_id'] = str(s['_id'])
        if isinstance(s.get('sale_date'), datetime):
            s['sale_date'] = s['sale_date'].isoformat()
    return jsonify({"success": True, "data": sales})

@app.route('/api/sales', methods=['POST'])
def add_sale():
    data = request.json
    
    all_sales = db.get_all_sales()
    next_id = max([s['_id'] for s in all_sales]) + 1 if all_sales else 1
    
    sale = {
        "_id": next_id,
        "item_id": data['item_id'],
        "quantity": data['quantity'],
        "price": data['price'],
        "total": data['total'],
        "employee_id": data['employee_id'],
        "sale_date": datetime.strptime(data['sale_date'], '%Y-%m-%d %H:%M:%S')
    }
    db.add_sale(sale)
    db.update_stock(data['item_id'], data['quantity'])
    return jsonify({"success": True, "message": "Sale recorded", "sale_id": next_id})

# ========== ORDERS API (for admin) ==========
@app.route('/api/orders', methods=['GET'])
def get_all_orders():
    customers = db.get_all_customers()
    all_orders = []
    for customer in customers:
        for order in customer.get('orders', []):
            order_copy = order.copy()
            order_copy['customer_id'] = customer['_id']
            order_copy['customer_name'] = customer['name']
            order_copy['customer_email'] = customer['email']
            all_orders.append(order_copy)
    return jsonify({"success": True, "data": all_orders})

@app.route('/api/orders/pending_count', methods=['GET'])
def get_pending_orders_count():
    customers = db.get_all_customers()
    pending_count = 0
    for customer in customers:
        for order in customer.get('orders', []):
            if order.get('status') == 'pending':
                pending_count += 1
    return jsonify({"success": True, "data": {"count": pending_count}})

# ========== AUTH API ==========
@app.route('/api/login', methods=['POST'])
def login():
    data = request.json
    user = db.get_user_by_username(data['username'])
    if user and data['password'] == user.get('password'):
        return jsonify({
            "success": True,
            "user": {
                "id": user['_id'],
                "username": user['username'],
                "role": user['role']
            }
        })
    return jsonify({"success": False, "message": "Invalid credentials"}), 401

@app.route('/api/logout', methods=['POST'])
def logout():
    return jsonify({"success": True, "message": "Logged out"})

# ========== HEALTH CHECK ==========
@app.route('/api/health', methods=['GET'])
def health():
    return jsonify({"status": "ok"})

# Create default admin if not exists
if db.users.count_documents({}) == 0:
    db.users.insert_one({
        "_id": 1,
        "username": "admin",
        "password": "admin123",
        "email": "admin@cafeflow.com",
        "role": "admin"
    })
    print("[INFO] Default admin created: admin / admin123")

if __name__ == '__main__':
    app.run(debug=True, port=5000)