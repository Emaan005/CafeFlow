import requests

BASE = "http://localhost:5000/api"

# 1. Get all products
print("1. Fetching products...")
r = requests.get(f"{BASE}/products")
if r.status_code == 200:
    products = r.json()['data']
    print(f"   ✅ Found {len(products)} products")
    for p in products[:3]:
        print(f"      - {p['name']}: ${p['price']}")
else:
    print(f"   ❌ Failed: {r.status_code}")

# 2. Get all categories
print("\n2. Fetching categories...")
r = requests.get(f"{BASE}/categories")
if r.status_code == 200:
    categories = r.json()['data']
    print(f"   ✅ Found {len(categories)} categories")
    for c in categories:
        print(f"      - {c['name']}")
else:
    print(f"   ❌ Failed: {r.status_code}")

# 3. Get all employees
print("\n3. Fetching employees...")
r = requests.get(f"{BASE}/employees")
if r.status_code == 200:
    employees = r.json()['data']
    print(f"   ✅ Found {len(employees)} employees")
    for e in employees:
        print(f"      - {e['name']} ({e['role']})")
else:
    print(f"   ❌ Failed: {r.status_code}")

# 4. Get all customers
print("\n4. Fetching customers...")
r = requests.get(f"{BASE}/customers")
if r.status_code == 200:
    customers = r.json()['data']
    print(f"   ✅ Found {len(customers)} customers")
    for c in customers:
        print(f"      - {c['name']} ({c['email']})")
else:
    print(f"   ❌ Failed: {r.status_code}")

print("\n✅ Database connection test complete!")