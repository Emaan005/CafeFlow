// auth_check.js - Updated for MongoDB API
$(document).ready(function() {
    console.log('🔐 Checking authentication...');
    
    const API_URL = 'http://localhost:5000/api';
    
    checkAuth();
    
    async function checkAuth() {
        try {
            // Check if admin is logged in (via localStorage)
            const adminUser = localStorage.getItem('cafe_admin');
            
            if (adminUser) {
                const userData = JSON.parse(adminUser);
                // Admin is logged in
                console.log('✅ Admin authenticated as:', userData.username);
                
                // Show username in navbar
                $('#user-info, #admin-info').text(`👤 ${userData.username} (${userData.role})`);
                
                // Load notifications for admin
                if (window.location.pathname.includes('dashboard.html')) {
                    loadAdminNotifications();
                }
                
            } else {
                // Check if customer is logged in
                const customerUser = localStorage.getItem('cafe_customer');
                
                if (customerUser) {
                    const userData = JSON.parse(customerUser);
                    // Customer is logged in
                    console.log('✅ Customer authenticated as:', userData.name);
                    
                    // Show username in navbar (for user pages)
                    if ($('#user-info').length) {
                        $('#user-info').text(`👤 ${userData.name}`);
                    }
                    
                } else {
                    // Not logged in at all, redirect based on page
                    const currentPage = window.location.pathname;
                    
                    // Admin pages → redirect to admin login
                    if (currentPage.includes('dashboard.html') || 
                        currentPage.includes('inventory.html') ||
                        currentPage.includes('employees.html') ||
                        currentPage.includes('analytics.html') ||
                        currentPage.includes('user_orders.html')) {
                        console.log('❌ Not authenticated, redirecting to admin login');
                        window.location.href = 'login.html';
                    }
                    // User pages → redirect to user login
                    else if (currentPage.includes('menu.html') ||
                             currentPage.includes('orders.html')) {
                        console.log('❌ Not authenticated, redirecting to user login');
                        window.location.href = 'user_login.html';
                    }
                    // Other pages → stay on page
                }
            }
        } catch (error) {
            console.error('❌ Auth check failed:', error);
            // Don't redirect from home/index pages
            if (!window.location.pathname.includes('index.html') &&
                !window.location.pathname.includes('login.html') &&
                !window.location.pathname.includes('user_login.html') &&
                !window.location.pathname.includes('register.html')) {
                window.location.href = 'index.html';
            }
        }
    }
    
    // Logout functionality
    $('#logout-btn').click(async function() {
        if (confirm('Are you sure you want to logout?')) {
            try {
                // Clear localStorage
                localStorage.removeItem('cafe_admin');
                localStorage.removeItem('cafe_customer');
                localStorage.removeItem('cafe_user');
                
                // Call logout endpoint if needed
                await fetch(`${API_URL}/logout`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' }
                }).catch(() => console.log('Logout endpoint not needed'));
                
                window.location.href = 'index.html';
            } catch (error) {
                console.error('Logout error:', error);
                // Still redirect even if API fails
                window.location.href = 'index.html';
            }
        }
    });
    
    // Helper function for admin notifications
    async function loadAdminNotifications() {
        try {
            // Get pending orders count from orders API
            const response = await fetch(`${API_URL}/orders/pending_count`);
            const result = await response.json();
            
            if (result.success && result.data.count > 0) {
                // Add badge to Customer Orders link in sidebar
                $('.side-nav a[href="user_orders.html"]').append(
                    `<span style="background: #ff5252; color: white; border-radius: 10px; padding: 2px 6px; font-size: 11px; margin-left: 5px;">
                        ${result.data.count}
                    </span>`
                );
            }
        } catch (error) {
            console.error('Notification load error:', error);
        }
    }
});