// CafeFlow frontend script with MongoDB backend
const API_URL = 'http://localhost:5000/api';

console.log('📦 script.js loaded! API_URL:', API_URL);

// ====== CORE FUNCTIONS ======
// Escape HTML for safe display
function escapeHtml(str){ 
    return String(str).replace(/[&<>"']/g, function(m){ 
        return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]; 
    }); 
}

// ====== API FUNCTIONS ======
async function loadItemsFromAPI() {
    console.log('📡 Loading items from API...');
    try {
        const response = await fetch(`${API_URL}/products`);
        console.log('📡 Response status:', response.status);
        const result = await response.json();
        console.log('📡 API result:', result.success ? `Success - ${result.data.length} items` : 'Failed');
        return result.success ? result.data : [];
    } catch (error) {
        console.log('❌ API failed:', error);
        return [];
    }
}

async function saveItemToAPI(item, isEdit = false) {
    console.log('💾 Saving item to API...', isEdit ? '(edit)' : '(new)');
    try {
        let response;
        if (isEdit) {
            response = await fetch(`${API_URL}/products/${item.id}`, {
                method: 'PUT',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(item)
            });
        } else {
            response = await fetch(`${API_URL}/products`, {
                method: 'POST',
                headers: {'Content-Type':application/json},
                body: JSON.stringify(item)
            });
        }
        return await response.json();
    } catch (error) {
        console.log('❌ Save API failed:', error);
        return {success: false, message: 'Network error'};
    }
}

async function deleteItemFromAPI(id) {
    console.log('🗑️ Deleting item ID:', id);
    try {
        const response = await fetch(`${API_URL}/products/${id}`, {
            method: 'DELETE'
        });
        return await response.json();
    } catch (error) {
        console.log('❌ Delete API failed:', error);
        return {success: false, message: 'Network error'};
    }
}

async function getCategoriesFromAPI() {
    console.log('🏷️ Loading categories from API...');
    try {
        const response = await fetch(`${API_URL}/categories`);
        const result = await response.json();
        console.log('🏷️ Categories result:', result.success ? `Success - ${result.data.length} categories` : 'Failed');
        return result.success ? result.data.map(c => c.name) : [];
    } catch (error) {
        console.log('❌ Categories API failed:', error);
        return [];
    }
}

// ====== RENDER FUNCTIONS ======
function buildCard(item){
    const low = item.stock > 0 && item.stock < 5;
    const out = item.stock === 0;
    const overlay = low ? '<div class="low-overlay"></div>' : (out ? '<div class="out-overlay"></div>' : '');
    const lowBadge = low ? '<div class="low-badge">⚠️ Low</div>' : '';
    const outClass = out ? 'out-muted' : '';
    
    return `
    <article class="inv-card ${outClass}" data-id="${item._id}" data-name="${escapeHtml(item.name).toLowerCase()}" data-category="${escapeHtml(item.category)}" data-stock="${item.stock}">
        ${overlay}
        ${lowBadge}
        <div class="inv-image">🥐</div>
        <div class="inv-title">${escapeHtml(item.name)}</div>
        <div class="inv-meta"><div>${escapeHtml(item.category)}</div><div>$${Number(item.price).toFixed(2)}</div></div>
        <div class="inv-meta" style="margin-top:8px"><div>Stock: <strong>${item.stock}</strong></div></div>
        <div class="inv-actions">
            <button class="btn-edit" data-id="${item._id}">Edit</button>
            <button class="btn-delete" data-id="${item._id}">Delete</button>
        </div>
    </article>
    `;
}

function renderInventory(items){
    console.log('🎨 Rendering inventory:', items.length, 'items');
    const $grid = $('#inventory-grid');
    if($grid.length === 0) {
        console.log('⚠️ #inventory-grid not found on this page');
        return;
    }
    $grid.empty();
    
    if(items.length === 0){
        $grid.append('<div class="card">No items match your search / filters.</div>');
        return;
    }
    
    items.forEach(it => {
        $grid.append(buildCard(it));
    });
    console.log('✅ Inventory rendered');
}

// ====== FILTER FUNCTIONS ======
async function applyFilters(){
    console.log('🔍 Applying filters...');
    const q = ($('#search-input').val()||'').trim().toLowerCase();
    const cat = $('#filter-category').val() || 'all';
    const stock = $('#filter-stock').val() || 'all';
    
    let items = await loadItemsFromAPI();
    console.log('🔍 Before filters:', items.length, 'items');
    
    // category filter
    if(cat !== 'all'){
        items = items.filter(i => i.category === cat);
        console.log('🔍 After category filter:', items.length, 'items');
    }

    // stock status filter
    if(stock === 'in') {
        items = items.filter(i => i.stock >= 5);
        console.log('🔍 After "in stock" filter:', items.length, 'items');
    }
    else if(stock === 'low') {
        items = items.filter(i => i.stock > 0 && i.stock < 5);
        console.log('🔍 After "low stock" filter:', items.length, 'items');
    }
    else if(stock === 'out') {
        items = items.filter(i => i.stock === 0);
        console.log('🔍 After "out of stock" filter:', items.length, 'items');
    }

    // live search filtered over name & category
    if(q){
        items = items.filter(i => 
            (i.name + ' ' + i.category).toLowerCase().includes(q)
        );
        console.log('🔍 After search filter:', items.length, 'items');
    }

    renderInventory(items);
}

// ====== CATEGORY FUNCTIONS ======
async function populateCategoryFilters(){
    console.log('🏷️ Populating category filters...');
    try {
        const categories = await getCategoriesFromAPI();
        console.log('🏷️ Categories loaded:', categories);
        
        const $cat = $('#filter-category');
        const $addCat = $('#item-category');
        const $editCat = $('#edit-category');
        
        if($cat.length){
            console.log('🏷️ Found #filter-category');
            $cat.empty().append('<option value="all">All Categories</option>');
            categories.forEach(c => $cat.append(`<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`));
        }
        
        if($addCat.length){
            console.log('🏷️ Found #item-category');
            $addCat.empty().append('<option value="">Select category</option>');
            categories.forEach(c => $addCat.append(`<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`));
        }
        
        if($editCat.length){
            console.log('🏷️ Found #edit-category');
            $editCat.empty().append('<option value="">Select category</option>');
            categories.forEach(c => $editCat.append(`<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`));
        }
        
        console.log('✅ Category filters populated');
    } catch (error) {
        console.error('❌ Error loading categories:', error);
    }
}

// ====== EVENT HANDLERS ======
function wireInventoryActions(){
    console.log('🔗 Wiring inventory actions...');
    // Edit button click
    $(document).on('click', '.btn-edit', function(){
        const id = $(this).data('id');
        console.log('✏️ Edit clicked for ID:', id);
        window.location.href = `edit_item.html?id=${encodeURIComponent(id)}`;
    });

    // Delete button click
    $(document).on('click', '.btn-delete', async function(){
        const id = $(this).data('id');
        console.log('🗑️ Delete clicked for ID:', id);
        if(!confirm('Delete this item from database?')) return;
        
        const result = await deleteItemFromAPI(id);
        if(result.success) {
            alert('Item deleted successfully!');
            await applyFilters(); // Refresh the list
            await updateStats(); // Update dashboard if visible
        } else {
            alert('Failed to delete: ' + (result.message || 'Unknown error'));
        }
    });
}

let searchTimeout = null;
function bindSearchAndFilters(){
    console.log('🔗 Binding search and filters...');
    $('#search-input').on('input', function(){
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => applyFilters(), 180);
    });

    $('#filter-category').on('change', applyFilters);
    $('#filter-stock').on('change', applyFilters);
}

// ====== FORM HANDLERS ======
function wireAddForm(){
    console.log('📝 Wiring add form...');
    $('#add-form').on('submit', async function(e){
        e.preventDefault();
        console.log('📝 Add form submitted');
        
        const name = $('#item-name').val().trim();
        const category = $('#item-category').val().trim();
        const price = parseFloat($('#item-price').val());
        const stock = parseInt($('#item-stock').val(), 10);
        
        console.log('📝 Form data:', {name, category, price, stock});
        
        if(!name || !category || Number.isNaN(price) || Number.isNaN(stock)) {
            console.log('❌ Form validation failed');
            return alert('Please fill all fields with valid data');
        }

        // Get next ID (simple approach - in production, let MongoDB handle this)
        const items = await loadItemsFromAPI();
        const nextId = items.length > 0 ? Math.max(...items.map(i => parseInt(i._id))) + 1 : 1;
        
        const newItem = { 
            id: nextId,
            name, 
            category_id: 1, // You'll need to map category name to ID
            category: category,
            price, 
            stock 
        };
        const result = await saveItemToAPI(newItem);
        
        if(result.success) {
            alert('✅ Item added to database!');
            window.location.href = 'inventory.html';
        } else {
            alert('❌ Failed to add item: ' + (result.message || 'Unknown error'));
        }
    });
}

async function wireEditForm(){
    console.log('📝 Wiring edit form...');
    const params = new URLSearchParams(window.location.search);
    const id = params.get('id');
    
    console.log('📝 Edit item ID from URL:', id);
    
    if(!id) {
        alert('No item ID specified');
        window.location.href = 'inventory.html';
        return;
    }

    if($('#edit-form').length){
        try {
            // Load item from database
            const response = await fetch(`${API_URL}/products`);
            const result = await response.json();
            
            if(!result.success) {
                alert('Failed to load items');
                window.location.href = 'inventory.html';
                return;
            }
            
            const item = result.data.find(i => i._id == id);
            if(!item) {
                alert('Item not found in database');
                window.location.href = 'inventory.html';
                return;
            }
            
            console.log('📝 Item loaded:', item);
            
            // Prefill form
            $('#edit-id').val(item._id);
            $('#edit-name').val(item.name);
            $('#edit-price').val(item.price);
            $('#edit-stock').val(item.stock);
            
            // Load and set category
            await populateCategoryFilters();
            $('#edit-category').val(item.category);
            
            // Handle form submission
            $('#edit-form').off('submit').on('submit', async function(e){
                e.preventDefault();
                console.log('📝 Edit form submitted');
                
                const editId = $('#edit-id').val();
                const name = $('#edit-name').val().trim();
                const category = $('#edit-category').val().trim();
                const price = parseFloat($('#edit-price').val());
                const stock = parseInt($('#edit-stock').val(), 10);
                
                console.log('📝 Edit form data:', {editId, name, category, price, stock});
                
                if(!name || !category || Number.isNaN(price) || Number.isNaN(stock)) {
                    return alert('Please fill all fields');
                }

                const result = await saveItemToAPI({ 
                    id: editId, 
                    name, 
                    category, 
                    price, 
                    stock 
                }, true);
                
                if(result.success) {
                    alert('✅ Item updated in database!');
                    window.location.href = 'inventory.html';
                } else {
                    alert('❌ Failed to update: ' + (result.message || 'Unknown error'));
                }
            });
            
        } catch (error) {
            console.error('❌ Error loading item:', error);
            alert('Error loading item data. Please try again.');
        }
    }
}

// ====== STATS FUNCTIONS ======
async function updateStats(){
    console.log('📊 Updating dashboard stats...');
    
    // Check if elements exist
    console.log('📊 #stat-total exists?', $('#stat-total').length > 0);
    console.log('📊 #stat-low exists?', $('#stat-low').length > 0);
    console.log('📊 #stat-cats exists?', $('#stat-cats').length > 0);
    
    try {
        const items = await loadItemsFromAPI();
        console.log('📊 Items loaded for stats:', items.length);
        
        // Debug: log first few items
        if (items.length > 0) {
            console.log('📊 Sample item:', items[0]);
        }
        
        // Update total items
        $('#stat-total').text(items.length);
        console.log('📊 Set total items to:', items.length);
        
        // Update low stock count
        const lowStock = items.filter(i => i.stock < 5 && i.stock > 0).length;
        $('#stat-low').text(lowStock);
        console.log('📊 Low stock items:', lowStock);
        
        // Update unique categories count
        const categories = [...new Set(items.map(i => i.category))];
        console.log('📊 Unique categories:', categories);
        $('#stat-cats').text(categories.length);
        console.log('📊 Unique categories count:', categories.length);
        
        console.log('✅ Stats updated successfully');
        
        // Test: Try to manually update to see if it works
        setTimeout(() => {
            console.log('🧪 Test: Current values in DOM:');
            console.log('🧪 Total:', $('#stat-total').text());
            console.log('🧪 Low:', $('#stat-low').text());
            console.log('🧪 Cats:', $('#stat-cats').text());
        }, 100);
        
    } catch (error) {
        console.error('❌ Error updating stats:', error);
    }
}

// ====== INITIALIZATION ======
$(document).ready(async function(){
    console.log('🚀 Document ready! Initializing...');
    console.log('🚀 jQuery version:', $.fn.jquery);
    console.log('🚀 Current page:', window.location.pathname);
    
    // Check what page we're on
    const isDashboard = $('#stat-total').length > 0;
    const isInventory = $('#inventory-grid').length > 0;
    const isAddPage = $('#add-form').length > 0;
    const isEditPage = $('#edit-form').length > 0;
    
    console.log('🚀 Page detection:', {
        isDashboard, 
        isInventory, 
        isAddPage, 
        isEditPage
    });
    
    // Always load categories for dropdowns (for forms)
    if (isInventory || isAddPage || isEditPage) {
        await populateCategoryFilters();
    }
    
    // Inventory page
    if(isInventory){
        console.log('📦 Initializing inventory page...');
        await applyFilters(); // This loads and renders items
        wireInventoryActions();
        bindSearchAndFilters();
    }
    
    // Dashboard page
    if(isDashboard){
        console.log('📊 Initializing dashboard page...');
        console.log('📊 Dashboard elements found:');
        console.log('📊 - #stat-total:', $('#stat-total').length);
        console.log('📊 - #stat-low:', $('#stat-low').length);
        console.log('📊 - #stat-cats:', $('#stat-cats').length);
        
        // Force update stats immediately
        await updateStats();
        
        // Also update after a short delay to ensure everything loaded
        setTimeout(async () => {
            console.log('⏰ Delayed stats update...');
            await updateStats();
        }, 500);
    }
    
    // Add item page
    if(isAddPage){
        console.log('➕ Initializing add item page...');
        wireAddForm();
    }
    
    // Edit item page
    if(isEditPage){
        console.log('✏️ Initializing edit item page...');
        await wireEditForm();
    }
    
    console.log('✅ Initialization complete!');
});

// Test API immediately when script loads
console.log('🔍 Testing API connection...');
fetch(`${API_URL}/products`)
    .then(response => {
        console.log('🔍 Initial API test status:', response.status);
        return response.json();
    })
    .then(data => {
        console.log('🔍 Initial API test result:', data.success ? '✅ Success' : '❌ Failed');
        if (data.success) {
            console.log('🔍 Items count from initial test:', data.data.length);
        }
    })
    .catch(error => {
        console.log('🔍 Initial API test failed:', error);
    });